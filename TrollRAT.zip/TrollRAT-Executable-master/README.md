# TrollRAT-Executable
THIS IS NOT MINE!!!! IT ALL BELONGS TO LEURAK!

I have given y'all the executable.
Welcome to paradise.

Original: https://github.com/Leurak/TrollRAT

Leurak needs more attention, and he also made the memz trojan!
